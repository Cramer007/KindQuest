# XRPL Commons training materials - 23/24 October 2023

This is a monorepo powered by [turborepo](https://turbo.build/repo).

## Install the dependencies.

Run `npm install`.

## Next steps

Go into each apps directory to look at the source code.
