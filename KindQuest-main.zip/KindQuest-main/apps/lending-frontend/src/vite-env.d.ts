/// <reference types="vite/client" />

interface Window {
  Buffer: typeof Buffer;
  process: any;
  global: any;
}
